#ifndef BANK_SERVO_H
#define BANK_SERVO_H

/**************************************************************************

Bank Servo Module
 
**************************************************************************/


/*-------------------------- Public Variables ---------------------------*/
/*-------------------------- Public Functions ---------------------------*/
void SetBankLevel(unsigned int left, unsigned int right);


#endif // BANK_SERVO_H