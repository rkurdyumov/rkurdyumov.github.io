#ifndef CLOCK_SERVO_H
#define CLOCK_SERVO_H

/**************************************************************************

Clock Servo Module
 
**************************************************************************/


/*-------------------------- Public Variables ---------------------------*/
/*-------------------------- Public Functions ---------------------------*/
void ResetClock(void);
void AdvanceClock(void);

#endif // CLOCK_SERVO_H