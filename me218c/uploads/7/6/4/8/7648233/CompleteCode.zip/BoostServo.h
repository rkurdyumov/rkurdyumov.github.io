#ifndef BoostServo
#define BoostServo

void InitBoostServo(void);
void UpdateBoostLevel(unsigned char Update);

#endif