#ifndef PICTIMER_H
#define PICTIMER_H

/*
This module contains a software PIC timer based on Timer0 overflows.  It requires the following:
(1) Global interrupts enabled
(2) Timer0 not used for anything else
(3) Running off a 20MHz oscillator
(3) Copy pasting the following into the interrupt response routine in the main C file:
if (TMR0IE && TMR0IF)
		TimerPIC_ISR();
(4) Including TimerPIC.h
*/
 
typedef enum { TimerPIC_ERR           = -1,
               TimerPIC_ACTIVE        =  1,
               TimerPIC_EXPIRED       =  1,
               TimerPIC_OK            =  0,
               TimerPIC_NOT_ACTIVE    =  0,
               TimerPIC_NOT_EXPIRED   =  0
} TimerPICReturn_t;

void TimerPIC_Init(void);
TimerPICReturn_t TimerPIC_InitTimer(unsigned char Num, unsigned int NewTime);
TimerPICReturn_t TimerPIC_IsTimerExpired(unsigned char Num);
unsigned int TimerPIC_GetTime(void);
void TimerPIC_ISR(void);

#endif   /* PICTIMER_H */