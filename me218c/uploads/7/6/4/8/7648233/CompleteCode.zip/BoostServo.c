//#define TEST_BOOST

/**************************************************************************

Boost Servo Module

Port T2
 
**************************************************************************/

/*---------------------------- Include Files ----------------------------*/
#include <mc9s12e128.h> /* derivative information */
#include "ME218_E128.h"	/* bit definitions */
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "S12eVec.h"		/* interrupts */ 
#include <timers12.h>
#include "BoostServo.h"
#include "SensorInputs.h"


/*--------------------------- Module Defines ----------------------------*/
#define FALSE           0
#define TRUE            1

#define HI_SIGNAL       0
#define LO_SIGNAL       1

#define _MS_ 			*3000
#define PERIOD 			(20_MS_)
#define START_POSITION	(2 _MS_)
#define	END_POSITION	(1 _MS_)
/*---------------------------- Module Types -----------------------------*/
/*-------------------------- Module Variables ---------------------------*/
static unsigned int HiTime = START_POSITION;
static unsigned char LastInterrupt = LO_SIGNAL;
/*-------------------------- Module Functions ---------------------------*/
void RespondToOC7(void);

/*------------------------ Interrupt Responses --------------------------*/

 // Servo Update: Timer 0 IC7 interrupt response 
void interrupt _Vec_tim0ch7 ServoCompare(void){
	static unsigned int ThisHiTime;
	
    TIM0_TFLG1 = _S12_C7F; /* clear IC7 flag */
    
    // Set next output compare based on if last time was low or high
    if (LastInterrupt == HI_SIGNAL){
        
        TIM0_TC7 = TIM0_TC7 + (PERIOD - ThisHiTime);
        LastInterrupt = LO_SIGNAL;
    }    
    else if (LastInterrupt == LO_SIGNAL){
        
        ThisHiTime = HiTime;
        TIM0_TC7 = TIM0_TC7 + ThisHiTime;
        LastInterrupt = HI_SIGNAL;
    }
	// Clear OC7 Flag
	TIM0_TFLG1 = _S12_C7F;
    
}


/*----------------------------- Module Code -----------------------------*/

void UpdateBoostLevel(unsigned char Update){
	unsigned int DutyCycle;
	
	DutyCycle = Update;
	HiTime = ((DutyCycle * ((START_POSITION - END_POSITION)/100)) + END_POSITION);
	
	//(void)printf("Hi Time %d Duty Cycle %d\r\n",HiTime,DutyCycle);
}

// This function sets up OC7
void InitBoostServo(void){
	
    TIM0_TSCR1 = _S12_TEN;
    TIM0_TIE = _S12_C7F;    /* enable output capture interrupts*/
	TIM0_TSCR2 = _S12_PR1|_S12_PR0; /* set pre-scale to /8 =3MHz timer clk*/
	TIM0_TIOS = (_S12_IOS4 | _S12_IOS7); /* set cap/comp 7 to output compare */
	TIM0_TCTL1 |= _S12_OL7; 	/* Toggle PT3 on compare*/
	TIM0_TCTL1 &= ~_S12_OM7;
	PTT &= BIT3LO;	// Start with low time and program the high 
	TIM0_TC7 = TIM0_TCNT + START_POSITION; /* schedule first rise */
	TIM0_TFLG1 = _S12_C7F; /* clear OC2 flag */
	
	// Setup first boost charging step
	(void) TMRS12_InitTimer(RECHARGE_TIMEOUT,RECHARGE_TIMEOUT_PERIOD);  //Start a timeout for next recharge interval

	
	EnableInterrupts;   // Enable global interrupts
}



#ifdef TEST_BOOST
   

//Main: Takes nothing, Returns nothing
void main(void) {

    char press;

    // Initialize: 
	InitBoostServo();
  	//TMRS12_Init(TMRS12_RATE_1MS);     	// Initialize 1ms timer
  	//(void) TMRS12_InitTimer(0,100);		// Set a 5ms timer to refresh Duty 
  	(void) printf("Initialized Boost Servo\r\n");
  	
    // Loop Forver
    while(1){
        
        CheckServoTimers();
    	    
      	 if(kbhit() == 1) {	
			    press = (char)getchar();
			    switch(press) {
				    case '1': 
				        (void)printf("Duty %d\r\n",DutyCycle);
				        DutyCycle = 0;

			    	break;
			    	
				    case '2': 
				        (void)printf("Duty %d\r\n",DutyCycle);
                        DutyCycle = 25;				        
  
			    	break;
			    	
				    case '3': 
				        (void)printf("Duty %d\r\n",DutyCycle);
                        DutyCycle = 50;
                        				        
			    	break;
			    	
				    case '4': 
						(void)printf("Duty %d\r\n",DutyCycle);		
                        DutyCycle = 75;				        
                        
			    	break;			    				    				    	

			        case '5':
			            (void)printf("Duty %d\r\n",DutyCycle);				
                        DutyCycle = 100;				        
                        
			        break;
			    }
      	 }    	
    	
    }// While Bracket
          
} // Main Bracket


#endif