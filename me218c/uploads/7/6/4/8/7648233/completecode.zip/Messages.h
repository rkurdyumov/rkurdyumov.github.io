#ifndef	MESSAGE
#define		MESSAGE

typedef enum{
	AtollSuccess, 	// Directed Message from Atoll
	AtollFailure, 	// Directed Message from Atoll
	AtollCaptured, 	// Broadcast Message from another ACV
	DriveCommand, 	// Directed Message from CVC
	TeammateACK,  	// Directed Message from Teammate
	ColorBroadcast, // Broadcast Message from Teammate
	ModemACK,		// Modem Acknowledgement That Message was Received
	NoMessage
}Message_t;

#endif