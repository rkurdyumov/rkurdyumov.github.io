#ifndef SensorInputs
#define SensorInputs

typedef enum{
  BUTTON_PRESS,
  NO_BUTTON
} Button_t;      


// Masks to turn on LED's for atoll status
#define ATOLL1      0x01
#define ATOLL2      0x02
#define ATOLL3      0x03
#define ATOLL4      0x04
#define ATOLL5      0x05

//Timers
#define		WHEEL_TIMEOUT			2
#define		WHEEL_TIMEOUT_PERIOD	750
#define		RECHARGE_TIMEOUT		3
#define		RECHARGE_TIMEOUT_PERIOD	200
#define		BOOST_TIMER				4
#define		BOOST_TIMER_LENGTH		4000
#define     RUNNING_TIMER           5
#define     RUNNING_TIMER_PERIOD    1000


//Public Functions
unsigned char ReadWheelDirection(void);
unsigned char ReadHandlebar(void);
unsigned char ReadHandlebarOld(void);
unsigned char ReadWheelSpeed(void);
Button_t ReadButton(void);
void CheckSensorTimeout(void);
void CheckBoostRecharge(void);
void AtollLED(unsigned char AtollNumber,unsigned char TeamColor);
void AtollLEDOff(void);
void InitPins(void);
void InitIC(void);
void InitDebug(void);
void UpdateDebug(void);
void InitBoostServo(void);
void UpdateBoostLevel(unsigned char Update);

#endif