#ifndef MAINIO_H
#define MAINIO_H

#define _MS_			*1250
#define	_100US_			*125
#define PERIOD			(200_100US_)
#define	RED_FLAG		(6_100US_)
#define	GREEN_FLAG		(27_100US_)
#define	NO_FLAG			(15_100US_)
#define	TIMEOUT_FLAG	(11_100US_)

void SetDuty(unsigned char LeftDuty, unsigned char RightDuty);
void InitPWM(void);
void InitADC(void);
void InitServo(void);
void SetServo(unsigned int Position);
void OutputCompareISR(void);
unsigned char ReadADC(void);

#endif   /* MAINIO_H */