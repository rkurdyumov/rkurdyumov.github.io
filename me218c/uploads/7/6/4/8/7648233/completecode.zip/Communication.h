#ifndef Communication
#define Communication


//General
#define   START_MESSAGE     0x7E
#define   API_TRANSMIT      0x01
#define   API_RECEIVE       0x81

//Addresses
#define   CVC_ADDRESS_MSB   0x20
#define   CVC_ADDRESS_LSB   0x8E
#define   ACV_ADDRESS_MSB   0x21
#define   ACV_ADDRESS_LSB   0x8E
#define   BROADCAST_MSB     0xFF
#define   BROADCAST_LSB     0xFF

//Command Types
#define   REQ_CAPTURE       0x66	
#define   REQ_CAPTURE_REPLY 0x67	
#define   FIND_TEAM         0x89	
#define   BROADCAST_CAPTURE 0xAB	
#define   COMMAND_C2B       0xCD 	// CVC to ACV (Controller to Boat)	
#define   COMMAND_B2C       0xEF 	// ACV to CVC (Boat to Controller)

//Options
#define   DIRECT_MESSAGE    0x02	// When transmitting
#define   BROADCAST_MESSAGE 0x00	// When receiving
#define	  ACK_ON			0x00	// When transmitting

// Colors
#define		RED				0xFE
#define		GREEN			0x01
#define		NO_COLOR		0x88

// Received Message
#define   	API               0
#define		RECEIVE_OPTION    4
#define		COMMAND_TYPE  	  5
#define 	ADDRESS_MSB		  1
#define		ADDRESS_LSB		  2
#define		TRANSMIT_STATUS	  2


// Atoll Capture Reply (pg.6)
#define		ATOLL_NUM_REPLY   6
#define		SUCCESS_FAIL  	  7
#define 	COLOR_REPLY		  8
// Announcing Atoll Capture (Broadcast to Everyone pg. 11)
#define   	TEAM_COLOR        6
#define   	ATOLL_NUMBER      7


#define		ATOLL_SUCCESS	    0xFF
#define		ATOLL_FAILURE	    0x00

typedef enum{
	NO_SWIPE,
	ATOLL1_SWIPE,
	ATOLL2_SWIPE,
	ATOLL3_SWIPE,
	ATOLL4_SWIPE,
	ATOLL5_SWIPE,
	RED_SWIPE,
	GREEN_SWIPE,
	WHITE_SWIPE
} Swipe_t;

#endif
	