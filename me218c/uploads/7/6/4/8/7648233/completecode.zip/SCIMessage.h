#ifndef SCIMessage_H
#define SCIMessage_H

#include "Messages.h"
/*---------------------------- Module Types -----------------------------*/
typedef enum {
	WAITING_FOR_START_BYTE,
	WAITING_FOR_MSB,
	WAITING_FOR_LSB,
	WAITING_FOR_DATA,
	WAITING_FOR_CHECKSUM
} ReceiveMessageState;

typedef enum{
  WAITING_FOR_PACKET,
  WAITING_FOR_TRANSMIT
} TransmitState_t;

#endif
/*-------------------------- Module Functions ---------------------------*/
void ReceiveMessageSM(void);
void TransmitSM(void);
unsigned char QueryMessage(int);
void InitComm(void);
unsigned char CheckNewMessage(void);
unsigned char ReturnDataSize(void);
Message_t ProcessMSG(void);
void CreatePacket(unsigned char DataLength, unsigned char MessageAddressMSB, unsigned char MessageAddressLSB, unsigned char Options, unsigned char CommandType, unsigned char DataToSend[]);
unsigned char CheckTransmit(void);