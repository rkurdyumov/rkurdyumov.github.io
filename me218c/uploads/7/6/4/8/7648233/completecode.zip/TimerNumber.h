// Timers
#define XBEETIMEOUT_TIMER 	0
#define SEND_TIMER 			1
#define TEAMMATE_TIMER		2
#define SEND_LED_TIMER		3
#define	CONTROL_TIMER		4

// Timeout Values
#define XBEETIMEOUT 		20
#define SENDTIMEOUT 		200
#define TEAMMATE_TIMEOUT	1000
#define	SEND_LED_TIMEOUT	100
#define	CONTROL_PERIOD		100